﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaborCarDealersip
{
    public partial class Stat : Form
    {
        CorvinusEntities context  = new CorvinusEntities();

        public Stat()
        {
            InitializeComponent();

            label1.Text = "\uE721";
            label2.Text = "\uE721";

            listBoxVasarlok.DisplayMember = "TulajdonosNév";
            listBoxEladóAutók.DisplayMember = "Márka";
            listBoxOrder.DisplayMember = "EladásiÁr";

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            VasarlokSzures();
        }

        private void VasarlokSzures()                   //itt van hiba, mégpedig utólag módositatottam a Vásárlók tábláin: hozzáadtam a végéhez email és telefon oszlopot...
        {                                               //nem a kommentelés volt a hiba, mert kivettem onnan és igy is hibát dob 
                                                        //pár órával később újra futtattam 30x és működött - ezt nem hiszem el: 2018.04.16. 21:41 perckor!!!!!
            var vlist = from v in context.Vásárlók.Local                
                        where v.TulajdonosNév.Contains(textBox1.Text)                   
                        select v;
            listBoxVasarlok.DataSource = vlist.ToList();
            //Tulajodonosnév tartalmazza a szövedoboznak a szövegét
        }

        private void Stat_Load(object sender, EventArgs e)
        {
            context.Vásárlók.Load();                                        //letöltöm a memóriába h ne a szerveren keressen
            context.Tipus.Load();
            context.Autó.Load();
            context.EladottAutó.Load();
            VasarlokSzures();                                               // load metódusban hivom, hogy látszódjon rögtön a szöveg
            AutosSzures();                                                  //inditáskor is látszódjona szöveg
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            AutosSzures();
        }

        private void AutosSzures()
        {
            var alist = from a in context.Tipus.Local
                        where a.Márka.Contains(textBox2.Text)
                        select a;
            listBoxEladóAutók.DataSource = alist.ToList();
        }

        private void listBoxVasarlok_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxVasarlok.SelectedItem == null)                       //ha nincs senki kiválasztva, akkor térjen vissza érték nélkül
                return;
            //a vásárlók listáját nyugodtan castolhatom Vásárlókká, mert velük töltöttem fel a listámat
            var s = (Vásárlók)listBoxVasarlok.SelectedItem;                 

            //1. lekérdezés = eladási ár középső listában
            var rendelesek = from x in context.EladottAutó
                      where x.VásárlókFK == s.TulajdonosSK
                      select new {x.EladásiÁr };                          
            listBoxOrder.DataSource = rendelesek.ToList();

            //2. lekérdezés = összes eladás értéke
            var eladasokOsszerteke = (from x in context.EladottAutó
                                      select x.EladásiÁr).Sum();
            textBox4.Text = eladasokOsszerteke.ToString();

            //3. beszerzési ár szummája
            var behozatalOsszerteke = (from x in context.Autó
                                       select x.BeszerzésiÁr).Sum();
          
            textBox3.Text = behozatalOsszerteke.ToString();
            textBox6.Text = (eladasokOsszerteke - behozatalOsszerteke).ToString();
                
        }
    }
}
