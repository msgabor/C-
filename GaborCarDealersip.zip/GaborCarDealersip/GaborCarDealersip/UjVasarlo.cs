﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaborCarDealersip
{

    public partial class UjVasarlo : Form
    {
        public UjVasarlo()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {

            TextBox txtb = (TextBox)sender;

            if (!String.IsNullOrEmpty(textBox1.Text))    //leellenőrzöm h üres v 1 a textbox1 tartalma (name)
            {
                e.Cancel = false;                        //ha minden rendben van, akkor nem validál ez jelenti h rendben van
                txtb.BackColor = Color.LightGreen;
            }
            else
            {
                e.Cancel = true;
                txtb.BackColor = Color.Red;
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            TextBox txtb = (TextBox)sender;
            if (!String.IsNullOrEmpty(textBox2.Text))    
            {
                e.Cancel = false;                       
                txtb.BackColor = Color.LightGreen;
            }
            else
            {
                e.Cancel = true;
                txtb.BackColor = Color.Red;
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
                                //sajnos nem vált zöldre valamiért, pedig több helyről leszedett email regex-el is próbáltam:( (stackoverflowról is próbáltam 3-at)

            Regex rex = new Regex(strRegex);

            if (rex.IsMatch(strRegex))
            {
                textBox3.BackColor = Color.LightGreen;
                e.Cancel = false;
            }
            else
            {
                textBox3.BackColor = Color.Red;
                e.Cancel = true;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }
    }
}
