﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaborCarDealersip
{
    public partial class EladottAutók : Form
    {
        CorvinusEntities kereskedes = new CorvinusEntities();       //létrehoztam egy példányt az adatbázisomból
        public EladottAutók()
        {
            InitializeComponent();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            UserControl5 uc = new UserControl5();
            panel1.Controls.Clear();
            panel1.Controls.Add(uc);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControl6 uc = new UserControl6();
            panel1.Controls.Clear();
            panel1.Controls.Add(uc);
        }
    }
}

