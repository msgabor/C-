﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaborCarDealersip
{
    public partial class Form1 : Form
        
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            EladóAutók f2 = new EladóAutók();             
            f2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EladottAutók f3 = new EladottAutók();             
            f3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Stat f4 = new Stat();
            f4.Show();
        }

    }
}
