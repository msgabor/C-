﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace GaborCarDealersip
{
    public partial class UserControl2 : UserControl
    {
        CorvinusEntities context = new CorvinusEntities(); //1.létrehoztam egy példányt az adatbázisomból
        public UserControl2()
        {
            InitializeComponent();
        }

        private void UserControl2_Load(object sender, EventArgs e)
        {
            context.Kategória.Load();
            kategóriaBindingSource.DataSource = context.Kategória.Local;
        }

        private void kategóriaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {

                kategóriaBindingSource.EndEdit();

                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }
    }
}
