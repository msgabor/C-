﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace GaborCarDealersip
{
    public partial class UserControl5 : UserControl
    {
        CorvinusEntities context = new CorvinusEntities();
        public UserControl5()
        {
            InitializeComponent();
        }

        private void UserControl5_Load(object sender, EventArgs e)
        {
            context.EladottAutó.Load();
            eladottAutóBindingSource.DataSource = context.EladottAutó.Local;
            context.Vásárlók.Load();
            vásárlókBindingSource.DataSource = context.Vásárlók.Local;
            
        }

        private void eladottAutóBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                eladottAutóBindingSource.EndEdit();
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
