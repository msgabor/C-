﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace GaborCarDealersip
{
    public partial class UserControl1 : UserControl
    {
        CorvinusEntities context = new CorvinusEntities(); //1.létrehoztam egy példányt az adatbázisomból

        public UserControl1()
        {
            InitializeComponent();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            context.Tipus.Load();                           //2. megmondom neki, hogy a context alatt lévő Tipus táblát töltse usercontrol 1-re
            tipuBindingSource.DataSource = context.Tipus.Local;
        }

        private void tipuBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                tipuBindingSource.EndEdit();
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
    }
}
