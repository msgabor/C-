﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaborCarDealersip
{
    public partial class EladóAutók : Form
    {
        CorvinusEntities kereskedes = new CorvinusEntities();       //létrehoztam egy példányt az adatbázisomból a Form 1 szintjén
        public EladóAutók()
        {
            InitializeComponent();
 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControl1 uc = new UserControl1();           //létrehozom az usercontrolokat
            panel1.Controls.Clear();                        //ezkell, különben a szinek nem változnak, egyik nem csapja felül a másikat
            panel1.Controls.Add(uc);                        //hozzáadom a panelhoz 
            uc.Dock = DockStyle.Fill;                       //usercontrol igy érje el a széleket, töltse ki
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserControl2 uc = new UserControl2();
            panel1.Controls.Clear();
            panel1.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UserControl3 uc = new UserControl3();
            panel1.Controls.Clear();
            panel1.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UserControl4 uc = new UserControl4();
            panel1.Controls.Clear();
            panel1.Controls.Add(uc);
            uc.Dock = DockStyle.Fill;
        }
    }
}
