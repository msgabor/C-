﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace GaborCarDealersip
{
    public partial class UserControl4 : UserControl
    {
        CorvinusEntities context = new CorvinusEntities(); //1.létrehoztam egy példányt az adatbázisomból

        public UserControl4()
        {
            InitializeComponent();
        }

        private void UserControl4_Load(object sender, EventArgs e)
        {
            context.Autó.Load();
            autóBindingSource.DataSource = context.Autó.Local;
            context.Üzemanyag.Load();
            üzemanyagBindingSource.DataSource = context.Üzemanyag.Local;

            context.Tipus.Load();
            tipuBindingSource.DataSource = context.Tipus.Local;

            context.Kategória.Load();
            kategóriaBindingSource.DataSource = context.Kategória.Local;

            
        }

        private void autóBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                tipuBindingSource.EndEdit();            //kényszeriti a folyamatban lévő szerkesztés befejezésését
                kategóriaBindingSource.EndEdit();
                üzemanyagBindingSource.EndEdit();
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            
            }

            
        }
    }
}

