﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace GaborCarDealersip
{
    public partial class UserControl6 : UserControl
    {
        CorvinusEntities context = new CorvinusEntities();  
        public UserControl6()
        {
            InitializeComponent();
        }

        private void UserControl6_Load(object sender, EventArgs e)
        {
            context.Vásárlók.Load();
            vásárlókBindingSource.DataSource = context.Vásárlók.Local;
           
        }

        private void vásárlókBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                vásárlókBindingSource.EndEdit();
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            UjVasarlo ujv = new UjVasarlo();
            ujv.Show();

        }
        //arra a fromra kell tenni ahonnan nyitottam az új vásárlókat, de ott sem jó sajnos
        UjVasarlo ujv = new UjVasarlo();
            if (ujv.ShowDialog() != DialogResult.OK) return;

            UjVasarlo customer = new UjVasarlo();

        customer.TulajdonosNév = ujv.textbox1.Text;
            customer.TulajdonosCím = ujv.textbox2.Text;
            customer.TulajdonosEmail = ujv.textbox3.Text;

            vásárlókBindingSource.Add(ujv);
    }
}
