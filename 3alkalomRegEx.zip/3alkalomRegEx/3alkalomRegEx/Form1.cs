﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3alkalomRegEx
{
    public partial class Form1 : Form
    {
        PeopleEntities context = new PeopleEntities();
        public Form1()
        {
            InitializeComponent();
            context.People.Load();
            personBindingSource.DataSource = context.People.Local;
        }
        private void personBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NewPersonForm f = new NewPersonForm();
            if (f.ShowDialog() != DialogResult.OK) return;
            //f.ShowDialog();

            Person p = new Person();        //léterhozok egy újszemély rekordot az OK lenyomásával

            p.Name = f.textBox1.Text;
            p.PersonalNumber = f.textBox2.Text;
            p.TaxNumber = f.textBox3.Text;
            p.Neptun = f.textBox4.Text;
            p.PhoneNumber = f.textBox5.Text;
            p.Email = f.textBox6.Text;

            personBindingSource.Add(p);
        }
    }
}


