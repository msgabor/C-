﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3alkalomRegEx
{
    public partial class NewPersonForm : Form
    {
        public NewPersonForm()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            TextBox txtb = (TextBox)sender;

            if (!String.IsNullOrEmpty(textBox1.Text))    //leellenőrzöm h üres v 1 a textbox1 tartalma (name)
            {
                e.Cancel = false;                        //ha minden rendben van, akkor nem validál ez jelenti h rendben van
                txtb.BackColor = Color.LightGreen;
            }
            else
            {
                e.Cancel = true;
                txtb.BackColor = Color.Red;
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            Regex rex = new Regex(@"(^$) | (^[A-Z]{2}-?[0-9]{6}$) | ");
            TextBox txtb = (TextBox)sender;

            if (rex.IsMatch(txtb.Text))                 //leellenőrzöm h üres v 1
            {
                e.Cancel = false;           
                txtb.BackColor = Color.LightGreen;
            }
            else
            {
                e.Cancel = true;
                txtb.BackColor = Color.Red;
            }
        }
    }
}
