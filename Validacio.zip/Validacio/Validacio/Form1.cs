﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Validacio
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxEmail_Validating(object sender, CancelEventArgs e)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                  @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                  @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(textBoxEmail.Text))
            {
                textBoxEmail.BackColor = Color.Yellow;
                e.Cancel = false;
            }
            else
            {
                textBoxEmail.BackColor = Color.FromArgb(255, 200, 200);
                e.Cancel = true;
                
            }
        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Validate();
        }



       
    }
}
