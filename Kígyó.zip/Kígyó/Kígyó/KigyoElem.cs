﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kígyó
{
    class KigyoElem : Button                //1. származtatom a Button osztályból, majd hozzáadom fent
    {
        public static int meret = 20;       //2. itt adom meg hogy 1 kigyóelem mekkora legyen

        public int sorszam;                 //3. ebbe tárolom el, hogy hányadikként leapkolt a kigyóelem

        public KigyoElem()                  //ctor tab tab Kigyóelemnek csináltam konstruktor
        {
            this.Height = meret;            //amikor a konstruktor lefut beállitja a kigyóelemet meret = 20; nagyságúra
            this.Width = meret;
            
        }
        public KigyoElem(int sorszam,  int x, int y)      //ez itt a függvénytúrterhelés, több paraméterrel hivok meg 1 ugyanazon függvényt
        {
            this.Height = meret;
            this.Width = meret;
            this.Top = y;
            this.Left = x;
            this.sorszam = sorszam;         //itt töltöm be a sorszám változóba az adatot a függvényen belül

            if (sorszam % 2 == 0)           //ha a sorszam kettővel vett osztási maradéka = 0 akkor lesz sárga a kocka, ergo minden páros kocka sárga lesz
            {
                this.BackColor = Color.Yellow;
            }
            else                            //különben minden páratlan fekete lesz
         
            {
                this.BackColor = Color.Black;
            }
        }

    }
}
