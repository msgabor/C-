﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kígyó
{
    public partial class Form1 : Form
    {
        int fejx = 100;
        int fejy = 100;
        int iranyX = 1;                 //jobbra kezd el menni a giliszta 1 egységgel
        int iranyY = 0;
        int hossz = 10;                  //ez határozzza majd meg hogy hányadikként letett elemet kell elvenni
        int sorszam = 0;                //ide tárolom az utoljára lerakott elemet

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            fejx += iranyX * KigyoElem.meret;
            fejy += iranyY * KigyoElem.meret;
            KigyoElem ujfej = new KigyoElem(sorszam, fejx, fejy);    //ezzel megszületik az új fej

            foreach (KigyoElem ke in this.Controls)                  //ezzel a cilkussal járom be a this.Controls lista elemeit. Kigyóelem tipusúvá castoljuk és ke néven kiszedegetjük
            {
                if (ke.Top == fejy &&ke.Left == fejx)                //itt pusztitom el a kigyót
                {
                    timer1.Enabled = false;                          //leállítom a timert h többet ne lépjen a kigyó
                    MessageBox.Show("Game Over - A kígyód megdöglött!");
                    Application.Exit();                             
                }
                if (ke.sorszam == sorszam - hossz)
                {
                    ke.Dispose();                                    //ezzel pusztitom el az utolsó darabját
                }
            }
            this.Controls.Add(ujfej);                                //ez a lista fogja tartalmazni a képernyőn lévő összes vezérlőt
            sorszam++;
            if (sorszam % 5 == 0)                                    //itt modnom meg h milyen időközönkánt nőjjön a farka és mennyivel
            {                                                               
                hossz++;
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)   //itt tanitom meg a kigyót fordulni
        {
         if (e.KeyValue == 65)               //65 értékkel A betű tér vissza, akkor jobbra fordul ezért X tengely -1, Y = 0  
            {
                iranyX = -1;
                iranyY = 0;
            }

         if (e.KeyValue == 68)
            {
                iranyX = 1;
                iranyY = 0;
            }
         if (e.KeyValue == 87)
            {
                iranyX = 0;
                iranyY = -1;
            }
         if (e.KeyValue == 83)
            {
                iranyX = 0;
                iranyY = 1;
            }
        }
    }
}
