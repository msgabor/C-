﻿namespace Tankonyvtamogatas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hallgatokListBox = new System.Windows.Forms.ListBox();
            this.rendelesekLlistBox = new System.Windows.Forms.ListBox();
            this.KonyvekListBox = new System.Windows.Forms.ListBox();
            this.hallgatokTextBox = new System.Windows.Forms.TextBox();
            this.KonyvekTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.támogatásÖsszértékTextBox = new System.Windows.Forms.TextBox();
            this.rendelesÖsszértékTextBox = new System.Windows.Forms.TextBox();
            this.hallgatóRendelésÉrtékTextBox = new System.Windows.Forms.TextBox();
            this.támagatásForintonkéntTextBox = new System.Windows.Forms.TextBox();
            this.hallgatóTámogatásaTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // hallgatokListBox
            // 
            this.hallgatokListBox.FormattingEnabled = true;
            this.hallgatokListBox.Location = new System.Drawing.Point(12, 51);
            this.hallgatokListBox.Name = "hallgatokListBox";
            this.hallgatokListBox.Size = new System.Drawing.Size(204, 394);
            this.hallgatokListBox.TabIndex = 0;
   
            // 
            // rendelesekLlistBox
            // 
            this.rendelesekLlistBox.FormattingEnabled = true;
            this.rendelesekLlistBox.Location = new System.Drawing.Point(238, 51);
            this.rendelesekLlistBox.Name = "rendelesekLlistBox";
            this.rendelesekLlistBox.Size = new System.Drawing.Size(224, 394);
            this.rendelesekLlistBox.TabIndex = 1;
            // 
            // KonyvekListBox
            // 
            this.KonyvekListBox.FormattingEnabled = true;
            this.KonyvekListBox.Location = new System.Drawing.Point(558, 51);
            this.KonyvekListBox.Name = "KonyvekListBox";
            this.KonyvekListBox.Size = new System.Drawing.Size(218, 394);
            this.KonyvekListBox.TabIndex = 2;
            // 
            // hallgatokTextBox
            // 
            this.hallgatokTextBox.Location = new System.Drawing.Point(12, 25);
            this.hallgatokTextBox.Name = "hallgatokTextBox";
            this.hallgatokTextBox.Size = new System.Drawing.Size(204, 20);
            this.hallgatokTextBox.TabIndex = 3;
            // 
            // KonyvekTextBox
            // 
            this.KonyvekTextBox.Location = new System.Drawing.Point(558, 25);
            this.KonyvekTextBox.Name = "KonyvekTextBox";
            this.KonyvekTextBox.Size = new System.Drawing.Size(218, 20);
            this.KonyvekTextBox.TabIndex = 4;
            
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(482, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(49, 43);
            this.button1.TabIndex = 5;
            this.button1.Text = ">";
            this.button1.UseVisualStyleBackColor = true;
         
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(482, 186);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(49, 47);
            this.button2.TabIndex = 6;
            this.button2.Text = "<";
            this.button2.UseVisualStyleBackColor = true;
         
            // 
            // támogatásÖsszértékTextBox
            // 
            this.támogatásÖsszértékTextBox.Location = new System.Drawing.Point(12, 472);
            this.támogatásÖsszértékTextBox.Name = "támogatásÖsszértékTextBox";
            this.támogatásÖsszértékTextBox.Size = new System.Drawing.Size(157, 20);
            this.támogatásÖsszértékTextBox.TabIndex = 7;
            this.támogatásÖsszértékTextBox.Text = "100000";
            // 
            // rendelesÖsszértékTextBox
            // 
            this.rendelesÖsszértékTextBox.Location = new System.Drawing.Point(12, 518);
            this.rendelesÖsszértékTextBox.Name = "rendelesÖsszértékTextBox";
            this.rendelesÖsszértékTextBox.Size = new System.Drawing.Size(157, 20);
            this.rendelesÖsszértékTextBox.TabIndex = 8;
            // 
            // hallgatóRendelésÉrtékTextBox
            // 
            this.hallgatóRendelésÉrtékTextBox.Location = new System.Drawing.Point(219, 472);
            this.hallgatóRendelésÉrtékTextBox.Name = "hallgatóRendelésÉrtékTextBox";
            this.hallgatóRendelésÉrtékTextBox.Size = new System.Drawing.Size(176, 20);
            this.hallgatóRendelésÉrtékTextBox.TabIndex = 9;
            // 
            // támagatásForintonkéntTextBox
            // 
            this.támagatásForintonkéntTextBox.Location = new System.Drawing.Point(219, 518);
            this.támagatásForintonkéntTextBox.Name = "támagatásForintonkéntTextBox";
            this.támagatásForintonkéntTextBox.Size = new System.Drawing.Size(176, 20);
            this.támagatásForintonkéntTextBox.TabIndex = 10;
            // 
            // hallgatóTámogatásaTextBox
            // 
            this.hallgatóTámogatásaTextBox.Location = new System.Drawing.Point(431, 472);
            this.hallgatóTámogatásaTextBox.Name = "hallgatóTámogatásaTextBox";
            this.hallgatóTámogatásaTextBox.Size = new System.Drawing.Size(156, 20);
            this.hallgatóTámogatásaTextBox.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 456);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Támogatás összérték:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(216, 456);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Hallgató rendelésének értéke:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 501);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Rendelések összértéke:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(216, 502);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Támogatás forintonként:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(428, 456);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Hallgatóra jutó támogatás:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 566);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hallgatóTámogatásaTextBox);
            this.Controls.Add(this.támagatásForintonkéntTextBox);
            this.Controls.Add(this.hallgatóRendelésÉrtékTextBox);
            this.Controls.Add(this.rendelesÖsszértékTextBox);
            this.Controls.Add(this.támogatásÖsszértékTextBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.KonyvekTextBox);
            this.Controls.Add(this.hallgatokTextBox);
            this.Controls.Add(this.KonyvekListBox);
            this.Controls.Add(this.rendelesekLlistBox);
            this.Controls.Add(this.hallgatokListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox hallgatokListBox;
        private System.Windows.Forms.ListBox rendelesekLlistBox;
        private System.Windows.Forms.ListBox KonyvekListBox;
        private System.Windows.Forms.TextBox hallgatokTextBox;
        private System.Windows.Forms.TextBox KonyvekTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox támogatásÖsszértékTextBox;
        private System.Windows.Forms.TextBox rendelesÖsszértékTextBox;
        private System.Windows.Forms.TextBox hallgatóRendelésÉrtékTextBox;
        private System.Windows.Forms.TextBox támagatásForintonkéntTextBox;
        private System.Windows.Forms.TextBox hallgatóTámogatásaTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

