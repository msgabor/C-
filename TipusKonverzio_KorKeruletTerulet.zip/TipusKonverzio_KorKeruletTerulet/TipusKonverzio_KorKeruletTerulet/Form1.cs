﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TipusKonverzio_KorKeruletTerulet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

                textBox1.BackColor = Color.White;                       //itt beadom neki, hogy legyen a "trycatch" blokk előtt fehér a box háttere

            try
            {
                //textbox1-ben (sugara a körnek)  double tipusú változóban kellene beolvasni az értéket, ám a textbox string tipusú, tehát konvertálni kell

                double sugar = double.Parse(textBox1.Text);             //Parse = konvertálás, majd megadom neki hogy a textbox1.szöveg tipust akarom double-re konvertálni
                double kerulet = sugar * 2 * Math.PI;                   //kerület számitás képlete Math.PI osztály segitséggel
                double terulet = Math.Pow(sugar, 2) * Math.PI;          //terület számitás egyenlete
                double kerekitett_kerulet = Math.Round(kerulet, 2);     //kerekités 2 tizedesjegyre
                double kerekitett_terulet = Math.Round(terulet, 2);     //kerekeités 2 tizedejegyre 

                textBox2.Text = kerekitett_kerulet.ToString();          //textbox2-nek a text részéhez rendelem a kerulet értékét, ámbár az szám, és stringgé konvertálom
                textBox3.Text = kerekitett_terulet.ToString();
            }
            catch (Exception)
            {
                textBox1.BackColor = Color.Red;                         //itt megváltozik a box háttere, ha stringet ir bele, de piros is marad
            }
            
      
            
        }
    }
}
