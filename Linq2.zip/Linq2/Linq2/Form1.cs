﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Linq2
{
    
    public partial class Form1 : Form
    {
        ServiceDatabaseEntities context = new ServiceDatabaseEntities();
        public Form1()
        {
            InitializeComponent();
            listBox2.DisplayMember = "NyersanyagNev";
            listBox1.DisplayMember = "FogasNev";
            NyersanyagListazas();
            FogasListazas();
            HozzavaloListazas();
        }

        private void NyersanyagListazas()
        {
            var nlist = from n in context.Nyersanyagok
                        where n.NyersanyagNev.Contains(textBox2.Text)
                        select n;

            listBox2.DataSource = nlist.ToList();
        }
        private void FogasListazas()
        {
            var flist = from f in context.Fogasok
                        where f.FogasNev.Contains(textBox1.Text)
                        select f;

            listBox1.DataSource = flist.ToList();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            HozzavaloListazas();

        }

        private void HozzavaloListazas()
        {
            var hozzavalok = from h in context.Receptek
                             where h.FogasID == ((Fogasok)listBox1.SelectedItem).FogasID
                             select new
                             {
                                 h.ReceptID,
                                 h.FogasID,
                                 h.Nyersanyagok.NyersanyagNev,
            
                                 h.Mennyiseg_4fo,
                                 h.Nyersanyagok.MennyisegiEgysegek.EgysegNev,
                                 Ar = h.Mennyiseg_4fo * (double?)h.Nyersanyagok.Egysegar
                             };
            bindingSource1.DataSource = hozzavalok.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Receptek r = new Receptek();
            r.FogasID = ((Fogasok)listBox1.SelectedItem).FogasID;
            r.NyersanyagID = ((Nyersanyagok)listBox2.SelectedItem).NyersanyagID;

            double m;
            if(!Double.TryParse(textBox3.Text, out m)) return;
            r.Mennyiseg_4fo = m;
            context.Receptek.Add(r);
            context.SaveChanges();
            HozzavaloListazas();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = ((Nyersanyagok)listBox2.SelectedItem).MennyisegiEgysegek.EgysegNev;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dynamic aktuális = bindingSource1.Current;
            int rid = aktuális.ReceptID;
            var törlendő = from r in context.Receptek
                           where r.ReceptID == rid
                           select r;
            context.Receptek.Remove(törlendő.FirstOrDefault());
            context.SaveChanges();
            HozzavaloListazas();
        }
    }
}
