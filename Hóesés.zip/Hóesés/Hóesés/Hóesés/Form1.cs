﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hóesés
{
    public partial class Form1 : Form
    {
        int létrehozás = 3;                     //Hozz létre egy globális változót, mely azt tárolja, hogy hány Tick eseményenként jöjjön létre hópihe, alapértéke legyen 3
        int számláló = 0;                       //1. Készíts egy számlálót a Tick eseményhez
        Random rnd = new Random();              //A példányosított hópihe bemeneti paraméterét egy random generátor adja meg a Form szélességének függvényében 

        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.Blue;                    //1. A Form háttérszíne legyen kék 
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (számláló % létrehozás == 0)             //2. Készíts egy számlálót a Tick eseményhez, és ha a számláló osztható az előző változóval, akkor.......
            {
                Hópihe h = new Hópihe(rnd.Next(this.Width));        //3. akkor példányosíts egy hópihét
                this.Controls.Add(h);                               //4. majd add hozzá a Form vezérlőihez
                h.vertical = rnd.Next(1, 5);        //A Hópihe függőleges mozgásának sebességét állítsd be egy újabb random generálással. A függőleges sebesség 1-4 közötti egész lehet 
            }
            számláló++;

            foreach (Hópihe h in this.Controls)     //Foreach-el menj végig az összes hópihén és változtasd meg a koordinátáikat a sebességeik függvényében. 
            {
                if (h.Visible)                      //i.	A foreachen belül csak azokra a Hópihékre fussanak le a korábban megírt véletlen generálások és mozgatások, amelyeknek a Visible tulajdonsága true 
                {
                    h.Left += h.horizontal;
                    h.Top += h.vertical;
                    h.horizontal = rnd.Next(-3, 4);        //Az oldal irányú sebességet minden tick esetén változtasd -3 és +3 között 

                    if (h.Top > this.Height)               //Ha egy hópihe eléri a Form alját akkor a Visible tulajdonságát állítsd false
                    {
                        h.Visible = false;
                    }
                }
            }
        }
    }
}
