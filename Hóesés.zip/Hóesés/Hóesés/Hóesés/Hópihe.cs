﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hóesés
{
    class Hópihe : Label                   //1. lépés, származtass osztályt a Label osztályból Hópihe néven
    {
        public int horizontal = 0;         //A hópihének legyen két publikus változója, melyek a mozgás irányát, és egyben a sebességét tárolják, és adj ezeknek alapértéket
        public int vertical = 0;

        public Hópihe(int x)                                    //ez a konstrukor, kapjon egy bemenő paramétert mely a Hópihe induló helyzetét tartalmazza
        {
            this.BackColor = Color.Transparent;                 //a konstruktorban állítsd be a Hópihe háttérszínét átlátszóra 
            this.Text = "*";                                    //(Color.Transparent), a Text-je legyen * karakter
            this.Font = new Font("Arial", 30, FontStyle.Bold);  //A font legyen new Font("Arial", 24, FontStyle.Bold)
            this.AutoSize = true;                               //AutoSize tulajdonsága legyen True
            this.ForeColor = Color.White;                       //A text-et állítsátok fehér színűre (ForeColor), 
            this.Left = x;                                      //a Top adott, mert a Form tetejétől indul, és ennek megfelelően állítsd be a Hópihe Left tulajdonságát 

        }
    }
}
