﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MasodFokuEgyenlet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBoxA_TextChanged(object sender, EventArgs e)
        {
            // 1. megadtam a 3 textboxnak a függvényt, hogy olvassa ki a beleirt adatokat
            // 2. double tipusú értékké kell kovertáljam őket
            // 3. try catch blokkba vagyok kénytelen tenni az egészet, mert ha pl üres, akkor az üres értéket nem tudja számmá konvertálni
            // 4 . létrehozom a diszkriminánst

            try
            {
                double a = double.Parse(textBoxA.Text);     //ezzel az első szövegbox van meg (parse = konvertálás)
                double b = double.Parse(textBoxB.Text);
                double c = double.Parse(textBoxC.Text);

                double diszkriminans = Math.Pow(b, 2) - 4 * a * c;  //ezzel megszültett a diszkriminánsunk


                //ha a diszrkimináns nagativ, akkor nem lehet az egyenletnek megoldása

                if (diszkriminans < 0)
                {
                    textBox1gyok.Visible = false;               //ezzel láthatatlaná tettem a szöveboxokat
                    textBox2gyok.Visible = false;
                }
                else
                {
                    textBox1gyok.Visible = true;               //ezzel láthatatlaná tettem a szöveboxokat
                    textBox2gyok.Visible = true;

                    double gyok1 = (-b + Math.Sqrt(diszkriminans)) / (2 * a);    //itt számolom az első gyököt
                    double gyok2 = (-b - Math.Sqrt(diszkriminans)) / (2 * a);    //itt a másodikat

                    //ha kész vagyok, belerakom a megtalált gyököket a dobozokba

                    textBox1gyok.Text = gyok1.ToString();                           // itt adom át gyok1 értékét a textboxak ami az első hatvány
                    textBox2gyok.Text = gyok2.ToString();    
                }
            }
            catch (Exception)
            {

            }

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
