﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SzoftTech2_adatbázis_lementése
{
    public partial class Form1 : Form
    {
        CorvinusEntities context = new CorvinusEntities(); //létrehoztam egy példányt az adatbázisomból
        public Form1()
        {
            InitializeComponent();
            context.Students.Load();        //ide kell jobbklikk lámpára - letöltöm az adatot
            dataGridView1.DataSource = context.Students.Local.ToBindingList(); //változtathatóvá teszem
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.Name = textBox1.Text;
            s.Neptun = textBox2.Text;
            s.BirthDate = dateTimePicker1.Value;
            s.AverageGrade = numericUpDown1.Value;
            s.IsActive = checkBox1.Checked;

            context.Students.Local.Add(s);
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            context.SaveChanges();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            //DialogResult vmi = sfd.ShowDialog(); //ez felhozza az ablakot, és elmenti vmi változóban h milyen módon lett bezárva az ablak
            if (sfd.ShowDialog() != DialogResult.OK) return;

            using (StreamWriter sw = new StreamWriter(sfd.FileName, false, Encoding.UTF8)) //megkapjuk a filenevet amit megadott a user
            {
                foreach (Student s in context.Students.Local) //végigmegyünk a sorokon amiket ki akarunk majd iratni
                {
                    sw.WriteLine($"{s.Name};{s.Neptun};{s.BirthDate};{s.AverageGrade};{s.IsActive}");
                }
            } //using miatt nem kell sw.Clsoe(); - igy tudunk memóriát spórolni, mert a }azonnal eldodbja

            
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() != DialogResult.OK) return;

            using (StreamReader sr = new StreamReader(ofd.FileName, Encoding.Default))
            {
                while (!sr.EndOfStream) //beolvasás, amig nem érem el a ciklus végét, addig olvass
                {
                    string[] sor = sr.ReadLine().Split(';'); //beolvassa az éppen aktuális sort és feldarabolja a pontosvesszők mentén

                    Student s = new Student();
                    s.Name = sor[0];
                    s.Neptun = sor[1];
                    s.BirthDate = DateTime.Parse(sor[2]); //szövegből konvertálás parse-sal megy
                    try
                    {
                        s.AverageGrade = Decimal.Parse(sor[3]); //ha üres a cella, elszállna, semmit, nem tud konvertálni, ezért kell trycatch-be
                    }
                    catch (Exception)
                    {
                        throw;              //maradjon null érték, ha nem tudod beolvasni, mert üres a cella
                    }
                    s.IsActive = bool.Parse(sor[4]);

                    context.Students.Local.Add(s);
                }
            }
            
        }
    }
}
