﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SzoftTech1
{
    public partial class Form1 : Form
    {
        BindingList<Hallgato> hlista = new BindingList<Hallgato>(); //form osztályon belül, de konstruktoron kivül létrehozok egy listát, amiben tárolok
                                                        //Binding - adatkötött objektum, igy lehet új sorokat felvenni és törölni újakat
        public Form1()                                //ez a konstruktor
        {
            InitializeComponent();
            Hallgato h = new Hallgato();
            h.Név = "Messzi-Szabo Gabor";
            h.Neptun = "JK0WCL";
            h.Átlag = 3.57;
            hlista.Add(h);                      //hozzőáadom a listához
            
            dataGridView1.DataSource = hlista;  //datagridview után az ablakban megjeleniti a hallgatót, akit létrehoztunk
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

    //teljesen külön osztály rész jön, de ezt érdemes külön file-ba, Hallgató példányt létrehozza
    //Student tábla megfelelője SQL-ből
    public class Hallgato
    {
        public string Név { get; set; }
        public string Neptun { get; set; }
        public DateTime SzületésiDátum { get; set; }
        public double Átlag { get; set; }
        public bool Aktív { get; set; }
    }

}
