﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memóriajáték
{
    public partial class Form1 : Form
    {
        Kártya előzőKártya;      //3.a Bővítsd a Form1 osztályt előzőKártya nevű, Kártya típusú referenciával, 
                                    //melyben mindig az előző kattintáskor kiválasztott kártyára fog mutatni

        public Form1()
        {
            InitializeComponent();
            StreamReader sr = new StreamReader("tabla.txt");   //2.a ozz létre példányt a StreamReader osztályból, melynek segítségével megnyitod a tabla.txt fájlt

            while (!sr.EndOfStream)                            //2.b Nem előírt lépésszámú ciklus segítségével járd be a fájlt, "addig amig a végére, nem értünk
            {
                string képfájl = sr.ReadLine();                //2.c   Nem előírt lépésszámú ciklus segítségével járd be a fájlt
                int x = Convert.ToInt32(sr.ReadLine());        //kiolvassa a fájlból a koordinátákat, ami a 2-3 sort jelenti, de konvertálni kell, mert string
                int y = Convert.ToInt32(sr.ReadLine());

                Kártya k = new Kártya(x, y, képfájl);          //2.d A ciklustörzsben hozz létre példányt a Kártya osztályból, a konstruktornak add át a fenti változókat!
                this.Controls.Add(k);                          //2.e Az előbb létrehozott példányt add hozzá az űrlapon szereplő vezérlők listájához

                k.Click += K_Click;     //3.b A fájlt olvasó ciklus törzsében rendelj közös eseménykiszolgáló függvényt a Kártya kattintás eseményéhez += tab tab
            }
        }
        private void K_Click(object sender, EventArgs e)
        {
            Kártya k = (Kártya)sender;      //3.c Az eseménykiszolgálóban hozz létre egy k nevű, Kártya típusú referenciát, mely értékéül a Kártya típusúvá castolt sender-t kapja
            if (előzőKártya != null)        //3.d A párok megtalálásának menete:Ellenőrizd, hogy az előzőKártya nem null - e!
            {
                if (előzőKártya.kép == k.kép)   //3.d II.	Ha nem, nézd meg, hogy k és előzőKártya kép tulajdonsága megegyezik-e! Ha megegyezik, tüntesd el őket
                {
                    k.Dispose();
                    előzőKártya.Dispose();
                }
            }
            előzőKártya = k;                //3.eVégül az előzőKártya referencia értékét állítsd be a k-ra            
        }
    }
}
