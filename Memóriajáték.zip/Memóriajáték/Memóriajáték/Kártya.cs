﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memóriajáték
{
    class Kártya : PictureBox                       //Származtass új osztályt Kártya, néven a PictureBox osztálytól!
    {
        public string kép;                          //1.f	A Kártya osztályt egészítsd ki kép nevű publikus változóval, mely alkalmas a képfájl nevének tárolására

        Timer timer = new Timer();                  //4.e   Az osztályt bővítsd egy Timerrel, mely Tick eseményéhet a konstruktorban hozz létre eseménykiszolgálót.

        public Kártya()                             //1.b Kártya osztályt bővítsd konstruktorral (ctor tab tab)
        {
            this.BackColor = Color.White;           //1.b beállitja a kártya hátlap szinét, F6, le kell build-elni, akkor jelenik meg az új osztály a toolboxban
        }
        public Kártya(int x, int y, string kép)     //1.b paraméterként átveszi a képernyőn elfoglalt pozíciót meghatározó x és y koordinátákat, valamint a kép nevét!
        {
            this.Image = Bitmap.FromFile("closed.png");      //1.c A konstruktor töltse be a képet! (this.Load(kép) //4.a b)	A kátya lefelé fordítva jelenjen meg: a konstruktor a "closed.png" nevű képet töltse be
            this.Top = y;                           //1.d A konstruktor állítsa be a Kártya pozícióját a képernyőn, valamint a képnek megfelelő szélességet és magasságot
            this.Left = x;
            this.Height = this.Image.Height;
            this.Width = this.Image.Width;
            this.kép = kép;                         //1.e	A konstruktor tárolja az osztály kép nevű változójába a paraméterként kapott képet
            this.Click += Kártya_Click;             //4.c   A konstruktorban rendelj eseménykiszolgáló függvényt a kattintás eseményhez
            timer.Interval = 1000;                  //4.e.  itt állitom be hogy a timer milyen időközöként forditsa vissza a kártyát
            timer.Tick += Timer_Tick;               //4.f   A Tick-hez tarozó eseménykiszolgálóban fordítsd le a kártyát
        }
        private void Timer_Tick(object sender, EventArgs e) 
        {
            this.Image = Bitmap.FromFile("closed.png"); //amikor a timer elsül, megint leforditom a kártyát
            timer.Stop();
        }
        private void Kártya_Click(object sender, EventArgs e)
        {
            this.Image = Bitmap.FromFile(kép);      //4.d  Az kattintáshoz tartozó eseménykiszolgálóban töltsd be a kép változóban tárolt képet, itt fordulnak fel a képek
            timer.Start();
          
        }
    }
}
