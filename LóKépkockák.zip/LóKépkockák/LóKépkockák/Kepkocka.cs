﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LóKépkockák
{
    class Kepkocka : PictureBox                                     //Kepkocka osztályt származtatom a PictureBox osztályból
    {
        int ox;
        int oy;
        bool moving = false;

        public Kepkocka()                                           //mivel még nem vonszolható a kép, létrehozoma Kepkocka osztály konstruktorát //ctor tab-tab
        {
            MouseDown += new MouseEventHandler(pbMouseDown);        //hozzárendelem a megfelelő kiszolgálófüggvényt
            MouseUp += new MouseEventHandler(pbMouseUp);
            MouseMove += new MouseEventHandler(pbMouseMove);
        }

        //esemélykezelők
        private void pbMouseDown(object sender, MouseEventArgs e)   //lenyomott egérgombnál következik be
        {
            moving = true;
            ox = e.X;
            oy = e.Y;
        }
        private void pbMouseUp(object sender, MouseEventArgs e)     //felengedett egérgombnál következik be
        {
            moving = false;
        }
        private void pbMouseMove(object sender, MouseEventArgs e)   //mozgatás közben következik be
        {
            if (moving)
            {
                ((PictureBox)sender).Left += e.X - ox;     //a sendert PictureBox-á cast-olom
                ((PictureBox)sender).Top += e.Y - oy;
            }
        }
    }
}
