﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LóKépkockák
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            int sorszam = 1;                            //for ciklusokon kivü hozom létre a változót, ami eldönti h hányadik képkockán járok

            for (int sor = 0; sor < 5; sor++)
                for (int oszlop = 0; oszlop < 5; oszlop++)
                    {
                        Kepkocka k = new Kepkocka();                    //létrehoztam 1 példányt a Képkocka osztályból
                        k.Load("lo_" + sorszam.ToString() + ".jpg");    //big/debug-ból olvasom be az első kockát

                        k.Top = sor * k.Image.Height;                   //itt állitom be, hogy hol helyezkedjen el a kép
                        k.Left = oszlop * k.Image.Width;

                        this.Controls.Add(k);                           //ezzel jelenik meg a kis képkocka a képernyőn

                        k.Height = k.Image.Height;                      //itt állitom be, hogy a kép mérete akkora legyen mint önmagáé
                        k.Width = k.Image.Width;

                        sorszam++;                                      //a sorszam nevű változóta ciklus végében inkrementálom is
                    }
            
        }


    }
}
