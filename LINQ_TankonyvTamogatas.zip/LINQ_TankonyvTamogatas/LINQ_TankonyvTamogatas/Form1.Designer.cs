﻿namespace LINQ_TankonyvTamogatas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtStudent = new System.Windows.Forms.TextBox();
            this.txtTextbook = new System.Windows.Forms.TextBox();
            this.listStudent = new System.Windows.Forms.ListBox();
            this.listTextbook = new System.Windows.Forms.ListBox();
            this.listOrder = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSupport = new System.Windows.Forms.TextBox();
            this.txtSumOfStudentOrders = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSupportOfStudent = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSumOfOrders = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSupportPerForint = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtStudent
            // 
            this.txtStudent.Location = new System.Drawing.Point(13, 13);
            this.txtStudent.Name = "txtStudent";
            this.txtStudent.Size = new System.Drawing.Size(198, 20);
            this.txtStudent.TabIndex = 0;
            this.txtStudent.TextChanged += new System.EventHandler(this.txtStudent_TextChanged);
            // 
            // txtTextbook
            // 
            this.txtTextbook.Location = new System.Drawing.Point(502, 13);
            this.txtTextbook.Name = "txtTextbook";
            this.txtTextbook.Size = new System.Drawing.Size(198, 20);
            this.txtTextbook.TabIndex = 1;
            this.txtTextbook.TextChanged += new System.EventHandler(this.txtTextbook_TextChanged);
            // 
            // listStudent
            // 
            this.listStudent.FormattingEnabled = true;
            this.listStudent.Location = new System.Drawing.Point(13, 40);
            this.listStudent.Name = "listStudent";
            this.listStudent.Size = new System.Drawing.Size(198, 303);
            this.listStudent.TabIndex = 2;
            this.listStudent.SelectedIndexChanged += new System.EventHandler(this.listStudent_SelectedIndexChanged);
            // 
            // listTextbook
            // 
            this.listTextbook.FormattingEnabled = true;
            this.listTextbook.Location = new System.Drawing.Point(502, 40);
            this.listTextbook.Name = "listTextbook";
            this.listTextbook.Size = new System.Drawing.Size(198, 303);
            this.listTextbook.TabIndex = 3;
            // 
            // listOrder
            // 
            this.listOrder.FormattingEnabled = true;
            this.listOrder.Location = new System.Drawing.Point(217, 40);
            this.listOrder.Name = "listOrder";
            this.listOrder.Size = new System.Drawing.Size(198, 303);
            this.listOrder.TabIndex = 4;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(421, 109);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 61);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "<";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(421, 176);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 61);
            this.btnRemove.TabIndex = 6;
            this.btnRemove.Text = ">";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 350);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Támogatás összértéke";
            // 
            // txtSupport
            // 
            this.txtSupport.Location = new System.Drawing.Point(13, 367);
            this.txtSupport.Name = "txtSupport";
            this.txtSupport.Size = new System.Drawing.Size(198, 20);
            this.txtSupport.TabIndex = 8;
            this.txtSupport.Text = "100000";
            this.txtSupport.TextChanged += new System.EventHandler(this.txtSupport_TextChanged);
            // 
            // txtSumOfStudentOrders
            // 
            this.txtSumOfStudentOrders.Location = new System.Drawing.Point(217, 367);
            this.txtSumOfStudentOrders.Name = "txtSumOfStudentOrders";
            this.txtSumOfStudentOrders.Size = new System.Drawing.Size(198, 20);
            this.txtSumOfStudentOrders.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(217, 350);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Hallgató rendelésének értéke";
            // 
            // txtSupportOfStudent
            // 
            this.txtSupportOfStudent.Location = new System.Drawing.Point(421, 367);
            this.txtSupportOfStudent.Name = "txtSupportOfStudent";
            this.txtSupportOfStudent.Size = new System.Drawing.Size(198, 20);
            this.txtSupportOfStudent.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(421, 350);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Hallgatóra jutó támogatás";
            // 
            // txtSumOfOrders
            // 
            this.txtSumOfOrders.Location = new System.Drawing.Point(13, 408);
            this.txtSumOfOrders.Name = "txtSumOfOrders";
            this.txtSumOfOrders.Size = new System.Drawing.Size(198, 20);
            this.txtSumOfOrders.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 391);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Rendelések összértéke";
            // 
            // txtSupportPerForint
            // 
            this.txtSupportPerForint.Location = new System.Drawing.Point(217, 408);
            this.txtSupportPerForint.Name = "txtSupportPerForint";
            this.txtSupportPerForint.Size = new System.Drawing.Size(198, 20);
            this.txtSupportPerForint.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(217, 391);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Támogatás forintonként";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 437);
            this.Controls.Add(this.txtSupportPerForint);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtSumOfOrders);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtSupportOfStudent);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSumOfStudentOrders);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSupport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.listOrder);
            this.Controls.Add(this.listTextbook);
            this.Controls.Add(this.listStudent);
            this.Controls.Add(this.txtTextbook);
            this.Controls.Add(this.txtStudent);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtStudent;
        private System.Windows.Forms.TextBox txtTextbook;
        private System.Windows.Forms.ListBox listStudent;
        private System.Windows.Forms.ListBox listTextbook;
        private System.Windows.Forms.ListBox listOrder;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSupport;
        private System.Windows.Forms.TextBox txtSumOfStudentOrders;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSupportOfStudent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSumOfOrders;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtSupportPerForint;
        private System.Windows.Forms.Label label5;
    }
}

