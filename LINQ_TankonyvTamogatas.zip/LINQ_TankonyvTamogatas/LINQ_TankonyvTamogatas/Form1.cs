﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ_TankonyvTamogatas
{
    public partial class Form1 : Form
    {
        TESTDBEntities context = new TESTDBEntities();

        public Form1()
        {
            InitializeComponent();

            context.Students.Load();
            context.Textbooks.Load();
            context.Orders.Load();

            listStudent.DisplayMember = "Name";
            listStudent.ValueMember = "StudentID";

            listTextbook.DisplayMember = "Title";
            listTextbook.ValueMember = "TextbookID";

            listOrder.DisplayMember = "Title";
            listOrder.ValueMember = "OrderSK";

            GetStudents();
            GetTextbooks();
            GetOrders();
        }

        private void txtStudent_TextChanged(object sender, EventArgs e)
        {
            GetStudents();
        }

        private void GetStudents()
        {
            var slist = from s in context.Students.Local
                        where s.Name.ToLower().Contains(txtStudent.Text.ToLower())
                        select s;
            listStudent.DataSource = slist.ToList();
        }

        private void txtTextbook_TextChanged(object sender, EventArgs e)
        {
            GetTextbooks();
        }

        private void GetTextbooks()
        {
            var tlist = from t in context.Textbooks.Local
                        where t.Title.ToLower().Contains(txtTextbook.Text.ToLower())
                        select t;
            listTextbook.DataSource = tlist.ToList();
        }

        private void GetOrders()
        {
            var olist = from o in context.Orders.Local
                        where o.StudentFK == (int)listStudent.SelectedValue
                        select new { o.OrderSK, o.Textbook.Title };
            listOrder.DataSource = olist.ToList();

            //--------------------------------------------------------------
            double support = double.Parse(txtSupport.Text);
            double? sumOfOrders = 
                (from o in context.Orders.Local
                 select o.Textbook.Price).Sum();
            double? sumOfStudentOrders = 
                (from o in context.Orders.Local
                 where o.StudentFK == (int)listStudent.SelectedValue
                 select o.Textbook.Price).Sum();
            double? supportPerForint = support / sumOfOrders;
            double? supportOfStudent = supportPerForint * sumOfStudentOrders;

            txtSumOfOrders.Text = sumOfOrders.ToString();
            txtSumOfStudentOrders.Text = sumOfStudentOrders.ToString();
            txtSupportPerForint.Text = supportPerForint.ToString();
            txtSupportOfStudent.Text = supportOfStudent.ToString();
        }

        private void listStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetOrders();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Order o = new Order();
            o.StudentFK = (int)listStudent.SelectedValue;
            o.TextbookFK = (int)listTextbook.SelectedValue;
            context.Orders.Local.Add(o);
            context.SaveChanges();
            GetOrders();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            var order = from o in context.Orders.Local
                        where o.OrderSK == (int)listOrder.SelectedValue
                        select o;
            context.Orders.Local.Remove(order.FirstOrDefault());
            context.SaveChanges();
            GetOrders();
        }

        private void txtSupport_TextChanged(object sender, EventArgs e)
        {
            GetOrders();
        }
    }
}
