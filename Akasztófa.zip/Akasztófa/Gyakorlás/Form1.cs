﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gyakorlás
{
    public partial class Form1 : Form
    {
        Random r = new Random();
        Akasztófa af;
        string megoldás;
        int találatok_száma = 0;
        int hibák_száma = 0;

        public Form1()
        {
            InitializeComponent();

            af = new Akasztófa();
            this.Controls.Add(af);
            af.Width = 200;
            af.Height = 200;
            af.Top = 20;
            af.Left = 300;

            string[] feladványok = { "EGY", "KETTŐ", "HÁROM", "NÉGY", "ÖT", "HAT", "HÉT", "NYOLC", "KILENC", "TÍZ" };
            StreamReader sr = new StreamReader("betűk.txt", Encoding.Default);            

            while (!sr.EndOfStream)
            {
                Label l = new Label();
                this.Controls.Add(l);
                l.Text = sr.ReadLine();
                l.Left = Convert.ToInt32(sr.ReadLine());
                l.Top = Convert.ToInt32(sr.ReadLine());
                l.Width = 25;
                l.Height = 25;
                l.BorderStyle = BorderStyle.FixedSingle;
                l.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                l.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
                l.Click += l_Click;
            }

            sr.Close();

            megoldás = feladványok[r.Next(feladványok.Length)];

            int counter = 0;
            foreach (char item in megoldás)
            {
                Betű b = new Betű();
                this.Controls.Add(b);
                b.Érték = item.ToString();
                b.Text = "_";
                b.Left = 50 + counter * b.Width;
                b.Top = 200;
                counter++;
            }
        }

        void l_Click(object sender, EventArgs e)
        {
            Label betű = (Label)sender;
            betű.Enabled = false;
            bool volt_találat = false;

            foreach (Betű item in this.Controls.OfType<Betű>())
            {
                Console.WriteLine(betű.Text);
                Console.WriteLine(item.Érték);
                if (betű.Text == item.Érték)
                {
                    találatok_száma++;
                    volt_találat = true;
                    item.Text = item.Érték;
                }
            }

            if (!volt_találat)
            {
                hibák_száma++;
                af.HibákSzáma++;
            }

            if (találatok_száma == megoldás.Length)
            {
                MessageBox.Show("Győztél!");
            }

            if (hibák_száma >= 10)
            {
                MessageBox.Show("Vesztettél!");
            }
        }
    }
}
