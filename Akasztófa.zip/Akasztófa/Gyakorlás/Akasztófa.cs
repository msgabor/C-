﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gyakorlás
{
    class Akasztófa : Panel
    {
        int[,] koordináták = new int[10, 4];
        Graphics g;
        Pen toll = new Pen(Color.Black);

        int hibákSzáma = 0;
        public int HibákSzáma
        {
            get { return hibákSzáma; }
            set
            {
                hibákSzáma = value;
                for (int i = 0; i < hibákSzáma; i++)
                {
                    if (i == 4)
                    {
                        g.DrawEllipse(toll, koordináták[i, 0], koordináták[i, 1], koordináták[i, 2], koordináták[i, 3]);
                    }
                    else
                    {
                        g.DrawLine(toll, koordináták[i, 0], koordináták[i, 1], koordináták[i, 2], koordináták[i, 3]);
                    }
                }
            }
        }


        public Akasztófa()
        {
            StreamReader sr = new StreamReader("akasztófa.txt", Encoding.Default);

            int counter = 0;
            while (!sr.EndOfStream)
            {
                koordináták[counter, 0] = Convert.ToInt32(sr.ReadLine());
                koordináták[counter, 1] = Convert.ToInt32(sr.ReadLine());
                koordináták[counter, 2] = Convert.ToInt32(sr.ReadLine());
                koordináták[counter, 3] = Convert.ToInt32(sr.ReadLine());
                counter++;
            }

            sr.Close();

            this.Paint += Akasztófa_Paint;
        }

        void Akasztófa_Paint(object sender, PaintEventArgs e)
        {
            g = this.CreateGraphics();
        }
    }
}
