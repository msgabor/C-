﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gyakorlás
{
    class Betű : Label
    {
        public string Érték { get; set; }

        public Betű()
        {
            this.Width = 25;
            this.Height = 25;
            this.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
        }
    }
}
